# Frontend Architecture: AI Authoring UI

## The Core Logic Patterns

1.  **The Polling Hook (`useAsyncTask`):** You must never `await` the rule generation API directly. The frontend must dispatch the intent, receive a `task_id`, and transition into a polling loop state (showing a spinner and progress text) until the BFF returns `SUCCESS` or `FAILED`.
2.  **Strict View Separation:** The Maker and the Checker should practically feel like they are using two different applications. We separate these at the root routing level based on the user's JWT role.
3.  **RFC 7807 Error Handling:** The UI must be capable of parsing the structured JSON errors we defined earlier (e.g., `422 Unprocessable Entity`) to highlight the exact word in the prompt that the AI couldn't map.

---

## 1. The API Client (`api.js`)

This file abstracts the `fetch` logic and enforces the mandatory enterprise headers required by the BFF.

```javascript
// src/services/api.js
const API_BASE = '/api/v1/authoring';

// Mock function to get the current user's token
const getToken = () => localStorage.getItem('jwt_token');
const getCorrelationId = () => crypto.randomUUID();

const fetchWithHeaders = async (endpoint, options = {}) => {
  const response = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${getToken()}`,
      'X-Correlation-ID': getCorrelationId(),
      ...options.headers,
    },
  });
  
  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    // Throw the RFC 7807 standard error object
    throw { status: response.status, ...errorData }; 
  }
  return response.json();
};

export const DraftService = {
  initialize: (payload) => fetchWithHeaders('/drafts', { method: 'POST', body: JSON.stringify(payload) }),
  submitIntent: (draftId, intent) => fetchWithHeaders(`/drafts/${draftId}/intent`, { method: 'PUT', body: JSON.stringify({ user_intent: intent }) }),
  pollTask: (taskId) => fetchWithHeaders(`/tasks/${taskId}`, { method: 'GET' }),
  submitForApproval: (draftId, notes) => fetchWithHeaders(`/drafts/${draftId}/submit`, { method: 'POST', body: JSON.stringify({ maker_notes: notes }) })
};

export const CheckerService = {
  getPending: () => fetchWithHeaders('/approvals/pending', { method: 'GET' }),
  approve: (draftId) => fetchWithHeaders(`/approvals/${draftId}/approve`, { method: 'POST' }),
  reject: (draftId, notes) => fetchWithHeaders(`/approvals/${draftId}/reject`, { method: 'POST', body: JSON.stringify({ checker_notes: notes }) })
};
```

---

## 2. The Asynchronous Polling Hook (`useRuleGeneration.js`)

This custom React hook is the heart of the Maker experience. It manages the chaotic transition between typing text and waiting for the LangGraph agent to finish.

```javascript
// src/hooks/useRuleGeneration.js
import { useState, useCallback } from 'react';
import { DraftService } from '../services/api';

export function useRuleGeneration() {
  const [status, setStatus] = useState('IDLE'); // IDLE, GENERATING, SUCCESS, ERROR
  const [ruleContract, setRuleContract] = useState(null);
  const [errorDetails, setErrorDetails] = useState(null);
  const [draftId, setDraftId] = useState(null);

  const generateRule = useCallback(async (intentPayload) => {
    setStatus('GENERATING');
    setErrorDetails(null);

    try {
      // 1. Initialize Draft
      const draftRes = await DraftService.initialize({
        portfolio_id: "RETAIL", product_code: "UNSECURED", jurisdiction: "US-TX"
      });
      setDraftId(draftRes.draft_id);

      // 2. Submit Intent (Returns 202 Accepted with Task ID)
      const intentRes = await DraftService.submitIntent(draftRes.draft_id, intentPayload);
      const taskId = intentRes.task_id;

      // 3. The Polling Loop (Every 2 seconds)
      const pollInterval = setInterval(async () => {
        try {
          const taskRes = await DraftService.pollTask(taskId);
          
          if (taskRes.status === 'SUCCESS') {
            clearInterval(pollInterval);
            setRuleContract(taskRes.draft_state.generated_rule);
            setStatus('SUCCESS');
          } else if (taskRes.status === 'FAILED') {
            clearInterval(pollInterval);
            setStatus('ERROR');
            setErrorDetails(taskRes.error_details); // Handles the 422 Hallucination errors
          }
        } catch (pollErr) {
          clearInterval(pollInterval);
          setStatus('ERROR');
          setErrorDetails(pollErr);
        }
      }, 2000);

    } catch (err) {
      setStatus('ERROR');
      setErrorDetails(err);
    }
  }, []);

  return { generateRule, status, ruleContract, errorDetails, draftId };
}
```

---

## 3. The Maker Dashboard (`MakerView.jsx`)

This UI component utilizes the hook above. Notice how it handles the RFC 7807 `actionable_feedback` we designed in the backend to explicitly tell the user *why* the AI failed.

```javascript
// src/views/MakerView.jsx
import React, { useState } from 'react';
import { useRuleGeneration } from '../hooks/useRuleGeneration';
import { DraftService } from '../services/api';

export default function MakerView() {
  const [intentText, setIntentText] = useState('');
  const { generateRule, status, ruleContract, errorDetails, draftId } = useRuleGeneration();

  const handleGenerate = () => {
    if (intentText.trim().length < 10) return;
    generateRule(intentText);
  };

  const handleSubmitApproval = async () => {
    await DraftService.submitForApproval(draftId, "Looks good to me.");
    alert("Sent to Checker Queue!");
    // Reset state in a real app
  };

  return (
    <div className="max-w-4xl mx-auto p-6 bg-white shadow rounded">
      <h1 className="text-2xl font-bold mb-4">Draft New Policy Rule</h1>
      
      {/* Input Area */}
      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-2">Business Intent (Plain English)</label>
        <textarea 
          className="w-full border p-3 rounded" rows="4" 
          placeholder="e.g., Decline anyone with FICO < 650..."
          value={intentText} onChange={(e) => setIntentText(e.target.value)}
          disabled={status === 'GENERATING'}
        />
        <button 
          className="mt-3 bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 disabled:opacity-50"
          onClick={handleGenerate}
          disabled={status === 'GENERATING'}
        >
          {status === 'GENERATING' ? 'AI is Analyzing...' : 'Generate Rule Contract'}
        </button>
      </div>

      {/* Error State (Handling our strict backend errors) */}
      {status === 'ERROR' && errorDetails && (
        <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
          <h3 className="text-red-800 font-bold">{errorDetails.title || "Generation Failed"}</h3>
          <p className="text-red-700">{errorDetails.detail}</p>
          {errorDetails.actionable_feedback && (
            <p className="mt-2 text-sm text-red-600 font-mono bg-red-100 p-2">{errorDetails.actionable_feedback}</p>
          )}
        </div>
      )}

      {/* Success State: Show the JSON/SpEL Contract */}
      {status === 'SUCCESS' && ruleContract && (
        <div className="border border-green-300 rounded overflow-hidden">
          <div className="bg-green-50 p-3 border-b border-green-300 flex justify-between items-center">
            <span className="font-bold text-green-800">Mathematically Validated</span>
            <button 
              onClick={handleSubmitApproval}
              className="bg-green-600 text-white px-3 py-1 rounded text-sm hover:bg-green-700"
            >
              Submit for Checker Approval
            </button>
          </div>
          <div className="p-4 bg-gray-50">
             <p className="text-sm font-bold text-gray-500 mb-1">Generated SpEL Logic:</p>
             <code className="block w-full bg-gray-800 text-green-400 p-3 rounded text-sm">
                {ruleContract.spel_expression}
             </code>
             
             <div className="mt-4 grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-bold text-gray-500">Action:</p>
                  <span className="inline-block bg-yellow-200 text-yellow-800 px-2 py-1 rounded font-bold text-xs">
                    {ruleContract.decision_action}
                  </span>
                </div>
                {ruleContract.enrichment_dependencies && (
                  <div>
                    <p className="text-sm font-bold text-gray-500">API Dependencies:</p>
                    <span className="text-xs text-gray-700">{ruleContract.enrichment_dependencies.join(', ')}</span>
                  </div>
                )}
             </div>
          </div>
        </div>
      )}
    </div>
  );
}
```

---

## 4. The Checker Dashboard (`CheckerView.jsx`)

This is the cryptographic gatekeeper UI. It is a read-only dashboard that ends in a binary decision: Append to the Ledger (Approve) or send back to the Maker (Reject).

```javascript
// src/views/CheckerView.jsx
import React, { useEffect, useState } from 'react';
import { CheckerService } from '../services/api';

export default function CheckerView() {
  const [pendingRules, setPendingRules] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadPending();
  }, []);

  const loadPending = async () => {
    setLoading(true);
    try {
      const res = await CheckerService.getPending();
      setPendingRules(res.pending_items || []);
    } catch (err) {
      alert("Failed to load queue. Check permissions.");
    }
    setLoading(false);
  };

  const handleApprove = async (draftId) => {
    if(!window.confirm("WARNING: Approving this writes it to the Immutable Ledger and deploys it to Production. Proceed?")) return;
    
    try {
      await CheckerService.approve(draftId);
      alert("Cryptographic hash generated. Rule Deployed.");
      loadPending(); // Refresh queue
    } catch (err) {
      alert(err.detail || "Approval failed.");
    }
  };

  if (loading) return <div className="p-6">Loading Secure Queue...</div>;

  return (
    <div className="max-w-5xl mx-auto p-6">
      <h1 className="text-3xl font-bold text-gray-800 mb-6 border-b pb-2">Senior Underwriter Queue</h1>
      
      {pendingRules.length === 0 ? (
        <p className="text-gray-500 italic">No rules currently pending your approval.</p>
      ) : (
        <div className="space-y-6">
          {pendingRules.map(rule => (
            <div key={rule.draft_id} className="bg-white border-2 border-gray-200 rounded-lg shadow-sm">
              <div className="bg-gray-50 px-4 py-3 border-b flex justify-between items-center">
                <div>
                  <span className="font-bold text-lg">{rule.rule_name || 'Draft Rule'}</span>
                  <span className="ml-4 text-sm text-gray-500">Draft ID: {rule.draft_id} | Maker: {rule.maker_id}</span>
                </div>
                <span className={`px-2 py-1 rounded text-xs font-bold ${rule.simulation_status === 'PASSED' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                  SIMULATION: {rule.simulation_status}
                </span>
              </div>
              
              <div className="p-4 grid grid-cols-2 gap-6">
                <div>
                  <h4 className="text-xs uppercase font-bold text-gray-400 mb-2">Maker's Original Intent</h4>
                  <p className="text-gray-800 text-sm italic border-l-4 border-gray-300 pl-3">"{rule.maker_intent}"</p>
                </div>
                <div>
                  <h4 className="text-xs uppercase font-bold text-gray-400 mb-2">Compiled SpEL Contract</h4>
                  <code className="block w-full bg-gray-100 text-gray-800 p-2 rounded text-sm overflow-x-auto">
                    {rule.generated_contract.spel_expression}
                  </code>
                </div>
              </div>

              <div className="bg-gray-100 px-4 py-3 border-t flex justify-end space-x-3">
                <button 
                  className="bg-white border border-red-500 text-red-600 px-4 py-2 rounded font-bold hover:bg-red-50"
                  onClick={() => {
                    const notes = prompt("Enter rejection reason for the Maker:");
                    if(notes) CheckerService.reject(rule.draft_id, notes).then(loadPending);
                  }}
                >
                  Reject & Return
                </button>
                <button 
                  className="bg-red-600 text-white px-6 py-2 rounded font-bold shadow hover:bg-red-700"
                  onClick={() => handleApprove(rule.draft_id)}
                >
                  Sign & Deploy to Production
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
```