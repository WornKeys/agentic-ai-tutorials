# API Contract: Service 3 - Validation & Graph Service (The Guardrail)

**Critical Architecture Note:** If Service 2 (The Python Orchestrator) is the "Brain," Service 3 is the "Firewall." Because it evaluates mathematical syntax and connects directly to the Neo4j database, it **must** be written in Java (Spring Boot). You cannot validate Spring Expression Language (SpEL) using a Python regex script; you must use the actual JVM compiler to ensure 100% parity with your Data Plane execution engine.

This service is strictly internal.

## API 1: Strict Schema & Syntax Validator
This endpoint acts as the deterministic bouncer. The LLM submits its generated JSON. This API verifies the Draft 2020-12 Schema and compiles the SpEL string into an Abstract Syntax Tree (AST) to catch syntax errors *before* they crash production.

* **Endpoint:** `POST /internal/validate/schema-and-syntax`
* **Request Body:**
```json
{
  "generated_contract": {
    "spel_expression": "credit_bureau.fico_score < 680 and financials.calculated_dti > 45",
    "routing_metadata": {"execution_stage": "STAGE_2_BUREAU"}
  }
}
```
* **Response - Success (200 OK):**
```json
{
  "is_valid": true,
  "compilation_time_ms": 12,
  "ast_nodes_verified": 5
}
```

## API 2: Business Logic & Conflict Detection
Just because a rule compiles perfectly does not mean it is legally or logically safe. This endpoint queries Neo4j to see if the *new* rule logically collides with an *existing, active* compliance rule.

* **Endpoint:** `POST /internal/validate/business-conflicts`
* **Request Body:**
```json
{
  "spel_expression": "credit_bureau.fico_score > 600",
  "decision_action": "APPROVE",
  "routing_metadata": {"jurisdictions": ["US-TX"]}
}
```
* **Response - Warning/Conflict Found (200 OK):** *(Note: Returns 200 because the API succeeded in finding the conflict, even though the rule is bad).*
```json
{
  "has_conflict": true,
  "conflict_severity": "BLOCKER",
  "conflicting_rule": {
    "rule_id": "RUL-COMP-001",
    "intent": "Mandatory decline for any FICO under 620 in Texas due to state regulation.",
    "spel_expression": "credit_bureau.fico_score < 620"
  },
  "resolution_feedback": "The proposed rule approves applicants with a FICO between 601 and 619, violating RUL-COMP-001."
}
```

## API 3: Graph Context Retrieval
This is the endpoint we mapped out previously. The Python Orchestrator calls this to fetch the allowed Data Dictionary subset before prompting the LLM.

* **Endpoint:** `POST /internal/graph/context`
* **Request Body:**
```json
{
  "extracted_keywords": ["income", "dti"],
  "product_code": "UNSECURED_PERSONAL"
}
```
* **Response (200 OK):**
*(Returns the pruned JSON schema and allowed target APIs/Enrichment dependencies based on the Neo4j traversal).*

---

## Strict Error Handling (RFC 7807 Problem Details)

When this service rejects a rule, it is not returning an error to a human. It is returning an error to the LangGraph AI loop. Therefore, the error message must be written specifically to prompt an LLM to self-correct.

### 1. The "Compilation / Syntax Failure" Error (400)
If the SpEL string contains bad math, unclosed parentheses, or illegal operators.

```json
{
  "type": "[https://errors.lending.internal/validator/spel-syntax-error](https://errors.lending.internal/validator/spel-syntax-error)",
  "title": "SpEL Compilation Failed",
  "status": 400,
  "detail": "The SpEL compiler threw a ParseException.",
  "ai_correction_prompt": "You generated an invalid SpEL string. Error at index 34: 'EL1041E: After parsing a valid expression, there is still more data in the expression: 'and''. Fix the logical operators.",
  "failed_expression": "credit_bureau.fico_score < 680 and and financials.calculated_dti > 45"
}
```

### 2. The "Schema / Dictionary Violation" Error (400)
If the JSON structure is wrong or the AI hallucinates a field.

```json
{
  "type": "[https://errors.lending.internal/validator/schema-violation](https://errors.lending.internal/validator/schema-violation)",
  "title": "JSON Schema Validation Failed",
  "status": 400,
  "detail": "The payload violates the Draft 2020-12 Enterprise Lending Dictionary constraint.",
  "ai_correction_prompt": "You attempted to use the key 'financials.net_income'. This key does not exist. You must use 'financials.base_annual_income'. Update the JSON.",
  "invalid_keys": ["financials.net_income"]
}
```

### 3. Graph Database Unreachable (503)
If Neo4j goes down, the Control Plane is flying blind.

```json
{
  "type": "[https://errors.lending.internal/validator/graph-unavailable](https://errors.lending.internal/validator/graph-unavailable)",
  "title": "Dependency Graph Unavailable",
  "status": 503,
  "detail": "Timeout while establishing a connection to the Neo4j cluster."
}
```

---

## Required Development Architecture for the Guardrail

This service is the legal firewall. Your Java engineers must implement these specific patterns to ensure it cannot be bypassed.

### 1. The "Dry Run" SpEL AST Compiler
You cannot just check if the string *looks* like code. You must force Spring to compile it into an Abstract Syntax Tree (AST) to verify it. 

```java
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.SpelParseException;

public class SpelValidator {
    private final ExpressionParser parser = new SpelExpressionParser();

    public ValidationResult validate(String generatedSpel) {
        try {
            // This does not execute the code, it only compiles the AST.
            // If the AI hallucinated a bad operator or unclosed parenthesis, it throws an exception here.
            parser.parseExpression(generatedSpel); 
            return ValidationResult.valid();
        } catch (SpelParseException e) {
            return ValidationResult.invalid("Syntax Error at position " + e.getPosition() + ": " + e.getMessage());
        }
    }
}
```

### 2. The Sandbox Constraint (CRITICAL SECURITY RISK)
SpEL is incredibly powerful. By default, it allows the instantiation of Java objects (`new java.lang.ProcessBuilder('rm','-rf','/').start()`). If the LLM goes rogue or a user attempts a prompt-injection attack via the UI, they could execute arbitrary code on your server.

Your `ExpressionParser` in this validation service (and in the Data Plane execution engine) **MUST** be configured with a restricted `SimpleEvaluationContext`. 

* **Rule:** Never use `StandardEvaluationContext` in a live engine unless you explicitly disable Java Type References, Constructor References, and Method Invocations. 
* **Implementation:** The context must be strictly limited to reading properties from your Jackson JSON `MapAccessor`. If the SpEL string contains a `new` keyword or a `T(...)` type reference, the validator must aggressively reject it with a 400 Bad Request.

### 3. The Neo4j Vector/Graph Overlay
For the Business Conflict detection (API 2) to work efficiently, you cannot write a single Cypher query that understands complex SpEL logic overlap. 
* **The Enterprise Pattern:** When a rule is approved, you convert the English intent into a text embedding (Vector) and store it as a property on the `(:Rule)` node in Neo4j. 
* When a new rule is proposed, Service 3 performs a **Vector Similarity Search** in Neo4j to find the 5 closest active rules, and *then* does a deterministic check to see if the boundaries overlap. This prevents the system from doing a brute-force scan of thousands of rules.