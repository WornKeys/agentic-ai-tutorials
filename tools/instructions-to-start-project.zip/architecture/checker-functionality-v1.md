# Architecture Mapping: The Checker Functionality

The human Checker functionality sits squarely inside **Service 1: Authoring BFF (Backend-For-Frontend)**. 

Because the Checker is a human Senior Underwriter interacting with a UI dashboard, they must go through the BFF. Service 1 is not just a proxy for the AI; it is the **State Manager** and the **RBAC (Role-Based Access Control) Enforcer** for the entire Control Plane.

Here is exactly how the Checker flow utilizes Service 1 and interacts with the rest of the architecture.

## Why it Belongs in Service 1 (Authoring BFF)

1. **Identity & Access Management:** Service 1 holds the logic that decodes the JWT token from your API Gateway. It is the only service that knows *who* the user is, which is strictly required to enforce the legal rule: `Token.UserId != Draft.MakerId`.
2. **State Orchestration:** Service 1 owns the PostgreSQL connection to the `authoring_rule_drafts` table. It controls the transition from `PENDING_CHECKER_APPROVAL` to `APPROVED` or `REJECTED`.
3. **Data Aggregation for the UI:** The Checker does not just look at math; they look at a dashboard. Service 1 aggregates the data for this dashboard. It pulls the SpEL string from the draft DB, fetches the latest simulation impact metrics from Service 4, and fetches the latest business conflict warnings from Service 3, packaging them into a single JSON response for the Checker's screen.

## The Architectural Handoff (The Boundary Crossing)

When the Checker clicks "Approve" in the UI, Service 1 executes the most critical boundary-crossing event in the platform. It moves the rule from the "Slow/Mutable AI Plane" to the "Fast/Immutable Data Plane."

Here is the step-by-step internal execution inside Service 1:

1. **The Cryptographic Lock:** Service 1 (Java/Node.js) generates the SHA-256 hash of the rule payload to ensure it can never be secretly altered.
2. **The Ledger Write:** Service 1 writes the data directly into the Postgres `production_rule_ledger` (the schema we just designed).
3. **The Pub/Sub Broadcast:** This is the crucial handoff. Service 1 cannot talk directly to the high-speed Spring Boot execution engine in the Data Plane (that would create a synchronous bottleneck). Instead, Service 1 fires an asynchronous message to the **Decision Event Bus (Kafka/RabbitMQ)**:
   * *Message Payload:* `{"event": "RULE_PROMOTED", "rule_id": "RUL-9044", "version": 2}`
4. **The Disconnect:** Once that Kafka message fires, Service 1 is done. The Control Plane's job is over. 
5. **Data Plane Takeover:** The `Cache Sync Service` (which lives in the Data Plane) consumes that Kafka message, reads the new rule from the Ledger DB, and pushes it into the high-speed Redis Cache for live execution.

By keeping the Checker flow inside Service 1, you completely isolate your production execution engine from human workflows, UI lag, and database state transitions.

# Architecture Deep Dive: The Checker Flow & Immutable Ledger

The Checker workflow requires a Senior Underwriter to review the AI's math, the historical simulation impact, and the business logic conflicts before authorizing deployment. 

## 1. The Checker API Contracts (Hosted on Service 1: BFF)

The UI for the Checker is a dedicated dashboard. These APIs ensure the Checker has 100% of the context required to make a legal sign-off.

### API 1: Fetch Pending Approvals Queue
* **Endpoint:** `GET /api/v1/authoring/approvals/pending`
* **Purpose:** Populates the Checker's dashboard. It must explicitly filter out any drafts authored by the currently logged-in user (Maker-Checker enforcement).
* **Response (200 OK):**
```json
{
  "pending_items": [
    {
      "draft_id": "drf_883abc91",
      "rule_name": "Thin File Alternative Data Router",
      "maker_id": "emp_49221",
      "submitted_at": "2026-04-11T08:35:00Z",
      "severity": "HIGH",
      "simulation_status": "PASSED"
    }
  ]
}
```

### API 2: Fetch Full Audit Context
* **Endpoint:** `GET /api/v1/authoring/approvals/{draft_id}/context`
* **Purpose:** This returns a massive aggregate payload. The Checker does not just view the SpEL string; they view the Maker's original English intent, the simulated financial delta, and any warnings from the Graph DB.
* **Response (200 OK):**
```json
{
  "draft_id": "drf_883abc91",
  "maker_intent": "If a Texas applicant...",
  "generated_contract": { "...": "..." },
  "simulation_results": {
    "approval_rate_delta": -2.3,
    "disparate_impact_ratio": 0.92
  },
  "graph_warnings": []
}
```

### API 3: Reject Draft (Back to Maker)
* **Endpoint:** `POST /api/v1/authoring/approvals/{draft_id}/reject`
* **Request Body:**
```json
{
  "checker_notes": "Simulation shows a disparate impact ratio of 0.92 for Texas. This is too close to the 0.80 regulatory threshold. Rework the logic to exclude medical debt."
}
```

### API 4: Cryptographic Approval & Promotion
* **Endpoint:** `POST /api/v1/authoring/approvals/{draft_id}/approve`
* **Purpose:** This is the most dangerous endpoint. It verifies the Maker != Checker constraint, generates a SHA-256 hash of the JSON, inserts it into the Immutable Ledger, and publishes the cache-warming event to the Data Plane.

---

## 2. The Database Strategy: Cryptographic Append-Only Ledger

If you are not using QLDB, you must enforce immutability at the Postgres database engine level. Your application code cannot be trusted to prevent `UPDATE` or `DELETE` statements. 

This schema utilizes a blockchain-style hash chain (`previous_version_hash`) and hard database triggers.

```sql
-- 1. Create the Ledger Table
CREATE TABLE production_rule_ledger (
    transaction_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- Business Identifiers
    rule_id VARCHAR(50) NOT NULL,            -- e.g., 'RUL-9044'
    rule_version INTEGER NOT NULL,           -- Auto-incrementing integer (1, 2, 3...)
    
    -- The Core Payload
    rule_payload JSONB NOT NULL,             -- The exact JSON SpEL contract deployed
    
    -- Maker/Checker Cryptographic Audit Trail
    maker_id VARCHAR(100) NOT NULL,
    checker_id VARCHAR(100) NOT NULL,
    approved_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    -- Blockchain-style Immutability Vectors
    payload_hash VARCHAR(64) NOT NULL,       -- SHA-256 of the rule_payload + maker_id + checker_id
    previous_version_hash VARCHAR(64),       -- The hash of the previous version of this specific rule_id
    
    -- Constraints
    CONSTRAINT chk_audit_separation CHECK (maker_id != checker_id),
    CONSTRAINT uq_rule_version UNIQUE (rule_id, rule_version)
);

-- 2. Create the Immutability Trigger Function
-- This physically prevents any DB Admin or rogue microservice from altering history.
CREATE OR REPLACE FUNCTION prevent_ledger_tampering()
RETURNS TRIGGER AS $$
BEGIN
    -- Block all UPDATE attempts
    IF TG_OP = 'UPDATE' THEN
        RAISE EXCEPTION 'CRITICAL AUDIT VIOLATION: Updates to the production_rule_ledger are strictly forbidden. You must append a new version.';
    END IF;
    
    -- Block all DELETE attempts
    IF TG_OP = 'DELETE' THEN
        RAISE EXCEPTION 'CRITICAL AUDIT VIOLATION: Deletions from the production_rule_ledger are strictly forbidden. To disable a rule, append a new version with active = false.';
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 3. Attach the Trigger to the Table
CREATE TRIGGER trg_enforce_immutability
    BEFORE UPDATE OR DELETE ON production_rule_ledger
    FOR EACH ROW
    EXECUTE FUNCTION prevent_ledger_tampering();

-- 4. High-Performance Read Index for the Cache Sync Service
-- The Cache Sync service only cares about the LATEST version of every rule.
CREATE INDEX idx_ledger_latest_rules ON production_rule_ledger (rule_id, rule_version DESC);
```

## 3. The Deployment Execution Flow

When the Checker hits API 4 (`/approve`), here is exactly what the backend executes:

1. **RBAC Verification:** Validates the Checker's JWT token has the `SENIOR_UNDERWRITER` role.
2. **Maker/Checker Check:** Ensures `Token.UserId != Draft.MakerId`.
3. **Hash Generation:** The Java backend takes the `generated_contract` JSON, serializes it deterministically (alphabetical keys, no whitespace), and generates a SHA-256 hash.
4. **Previous Hash Retrieval:** It queries the ledger for `SELECT payload_hash FROM production_rule_ledger WHERE rule_id = 'RUL-9044' ORDER BY rule_version DESC LIMIT 1`.
5. **Ledger Commit:** It executes the `INSERT` statement into the `production_rule_ledger`.
6. **State Update:** It updates the mutable `authoring_rule_drafts` table, setting the status to `APPROVED` so the draft locks in the UI.
7. **Cache Invalidation Event:** It fires a Kafka message: `{"event": "RULE_PROMOTED", "rule_id": "RUL-9044", "version": 2}`. The Data Plane Cache Sync Service consumes this, queries the Ledger for the new JSON, and hot-swaps the Redis cache.