# API Contract: Service 2 - Agent Orchestrator (Hyper-Realistic Enterprise Variant)

**Critical Architecture Note:** This service is **Strictly Internal**. It is never exposed to the API Gateway. The only authorized consumer is Service 1 (Authoring BFF). Authentication is handled via Service-to-Service mTLS or internal infrastructure tokens.

## API 1: Execute Generation Graph
This endpoint triggers the cyclical LangGraph state machine. The LLM is tasked with generating the full enterprise routing and execution payload, not just a simple SpEL string.

* **Endpoint:** `POST /internal/orchestrate/generate`
* **Request Body:**
```json
{
  "draft_id": "drf_883abc91",
  "user_intent": "If a Texas applicant applying for an unsecured loan has a thin Equifax file (FICO = 0 or history < 6 months), pause the decision and call LexisNexis for alternative data.",
  "context_constraints": {
    "product_code": "UNSECURED_PERSONAL",
    "jurisdiction": "US-TX"
  },
  "max_retries": 3
}
```
* **Response - Success (200 OK):**
```json
{
  "draft_id": "drf_883abc91",
  "status": "TERMINAL_SUCCESS",
  "execution_metrics": {
    "total_llm_calls": 2,
    "validation_failures_caught": 1,
    "total_latency_ms": 9150
  },
  "final_contract": {
    "rule_id": "RUL-9044",
    "rule_version": "1.0.0",
    "rule_name": "Thin File Alternative Data Router",
    "intent": "If a Texas applicant applying for an unsecured loan has a thin Equifax file (FICO = 0 or history < 6 months), pause the decision and call LexisNexis for alternative data.",
    "routing_metadata": {
      "execution_stage": "STAGE_2_BUREAU",
      "rule_sets": ["THIN_FILE_MATRIX", "STANDARD_UNDERWRITING"],
      "jurisdictions": ["US-TX"],
      "product_codes": ["UNSECURED_PERSONAL"]
    },
    "enrichment_dependencies": [
      "EQUIFAX_PRIMARY"
    ],
    "spel_expression": "credit_bureau.fico_score == 0 or credit_bureau.months_since_oldest_tradeline < 6",
    "decision_action": "SUSPEND_AND_ENRICH",
    "action_payload": {
      "target_api": "LEXIS_NEXIS_RISKVIEW",
      "retry_stage": "STAGE_3_ALTERNATIVE_DATA"
    },
    "active": true
  }
}
```

## API 2: Reverse Translation (Explain)
When auditors review legacy rules, they need the AI to translate the entire waterfall context back into English, not just the math.

* **Endpoint:** `POST /internal/orchestrate/explain`
* **Request Body:**
```json
{
  "rule_contract": {
     "routing_metadata": {"execution_stage": "STAGE_2_BUREAU", "jurisdictions": ["US-TX"]},
     "enrichment_dependencies": ["EQUIFAX_PRIMARY"],
     "spel_expression": "credit_bureau.fico_score == 0",
     "decision_action": "SUSPEND_AND_ENRICH",
     "action_payload": {"target_api": "LEXIS_NEXIS_RISKVIEW"}
  }
}
```
* **Response (200 OK):**
```json
{
  "human_readable_intent": "For Texas applications in the Bureau Stage, ensure Equifax data is loaded. If the FICO score is 0, suspend the rule engine and trigger a LexisNexis RiskView API call."
}
```

---

## Strict Error Handling (RFC 7807 Problem Details)

With the added complexity of routing matrices and third-party dependencies, the LLM has more ways to fail. The orchestrator must trap these specific enterprise failures.

### 1. The "Invalid Dependency / Orchestration Hallucination" Error (422)
If the LLM invents a third-party API that your orchestration layer doesn't support, or maps the rule to an invalid execution stage.

```json
{
  "type": "[https://errors.lending.internal/agent/invalid-orchestration-schema](https://errors.lending.internal/agent/invalid-orchestration-schema)",
  "title": "Orchestration Metadata Invalid",
  "status": 422,
  "detail": "The AI generated an invalid orchestration payload after 3 attempts.",
  "agent_trace": [
    "Attempt 1: Failed - 'STAGE_5_FINAL' is not a valid execution_stage Enum.",
    "Attempt 2: Failed - 'CREDIT_KARMA_API' is not a registered target_api in the enterprise registry.",
    "Attempt 3: Failed - Missing required enrichment_dependency for SpEL field 'credit_bureau'."
  ]
}
```

### 2. External Provider Failure (502 Bad Gateway)
If your enterprise LLM endpoint (Azure OpenAI, AWS Bedrock) goes down, throttles you, or throws a 500.

```json
{
  "type": "[https://errors.lending.internal/agent/upstream-provider-error](https://errors.lending.internal/agent/upstream-provider-error)",
  "title": "LLM Provider Unavailable",
  "status": 502,
  "detail": "The upstream foundation model provider rejected the request or timed out.",
  "provider": "AZURE_OPENAI_GPT4",
  "provider_status_code": 429
}
```

---

## Required Development Architecture for the Hyper-Realistic Agent Loop

Because the LLM is now generating complex metadata alongside the math, your engineering constraints must be brutal.

### 1. The Multi-Step Generation Node
Do not ask the LLM to generate the entire JSON contract in a single zero-shot prompt. You will get massive hallucination rates. Break the LangGraph node into a Chain-of-Thought pipeline:
* **Step 1 (Routing Extractor):** Extract the `jurisdictions`, `product_codes`, and `execution_stage`.
* **Step 2 (Dependency Mapper):** Look at the nouns in the intent (e.g., "Equifax", "LexisNexis") and map them strictly to the `enrichment_dependencies` and `action_payload` Enums.
* **Step 3 (SpEL Compiler):** Generate the actual `spel_expression` using the Data Dictionary.
* **Step 4 (Assembler):** Combine the outputs into the final JSON schema.

### 2. The Upgraded System Prompt Injection
You must provide the LLM with the Enums for your enterprise architecture, not just the Data Dictionary.

```text
You are a highly constrained enterprise lending architect. 
Your ONLY job is to translate the user's intent into a specific JSON Rule Contract.

CONSTRAINTS:
1. You may ONLY use the exact keys provided in the Data Dictionary for the 'spel_expression'.
2. You must map API requests ONLY to the Allowed Target APIs list.
3. You must map data dependencies ONLY to the Allowed Enrichment Providers list.
4. You must output raw JSON.

ALLOWED TARGET APIs: ["LEXIS_NEXIS_RISKVIEW", "PLAID_INCOME", "EXPERIAN_PRECISE_ID"]
ALLOWED ENRICHMENT PROVIDERS: ["EQUIFAX_PRIMARY", "EXPERIAN_PRIMARY", "TRANSUNION_PRIMARY"]
ALLOWED EXECUTION STAGES: ["STAGE_1_KNOCKOUT", "STAGE_2_BUREAU", "STAGE_3_AFFORDABILITY"]

DATA DICTIONARY:
{injected_json_schema}

USER INTENT:
{user_intent}
```

### 3. The TDD (Test-Driven Development) Loop for AI
Your evaluation dataset must now test the LLM's ability to deduce dependencies.
* **Test Case:** "Reject if Plaid shows less than $1000 in checking."
* **Assertion:** The test MUST fail if the LLM writes the SpEL logic but forgets to add `"PLAID_INCOME"` to the `enrichment_dependencies` array. If the orchestrator doesn't fetch the Plaid data before hitting the Data Plane, the execution engine will crash with a Null Pointer Exception. The AI is responsible for setting up the data pipeline via this metadata.


# Architecture Deep Dive: Agent Orchestrator to Graph DB Interaction

**Rule of Microservices:** The Python Agent Orchestrator (Service 2) must never hold database credentials for Neo4j. It must request sub-graphs via REST/gRPC from the Java Graph Service (Service 3), which owns the database schema.

## 1. The Interaction Sequence

When the Python Orchestrator starts the LangGraph loop, it executes this sequence *before* it ever calls the LLM:

1. **Intent Parsing (Fast LLM Call):** The Orchestrator does a cheap, fast zero-shot LLM call to extract "Nouns" from the user's intent. (e.g., User says: "If FICO is low, call LexisNexis". Extracted nouns: `["FICO", "LexisNexis"]`).
2. **Context Request:** Python sends these nouns to the Java Graph Service.
3. **Graph Traversal:** The Java service executes a Cypher query in Neo4j to find those nodes, their immediate parents, and their allowed execution stages.
4. **Context Assembly:** Java translates the Neo4j graph result into a localized JSON Schema and a list of valid Enums.
5. **Prompt Injection:** Python receives this localized schema, injects it into the System Prompt, and triggers the heavy LLM generation step.

---

## 2. The Neo4j Graph Data Model

To understand the interaction, you must understand how the enterprise lending data is mapped in Neo4j. It is not just a list of fields; it is a web of dependencies.

**Node Labels:**
* `(:DataField)` -> e.g., `fico_score`, `months_since_oldest_tradeline`
* `(:Entity)` -> e.g., `credit_bureau`, `financials`
* `(:ExternalAPI)` -> e.g., `LEXIS_NEXIS_RISKVIEW`
* `(:ExecutionStage)` -> e.g., `STAGE_2_BUREAU`

**Relationships (Edges):**
* `(:DataField)-[:BELONGS_TO]->(:Entity)`
* `(:Entity)-[:FETCHED_BY]->(:ExternalAPI)`
* `(:ExternalAPI)-[:AVAILABLE_IN]->(:ExecutionStage)`

*Why this matters:* If the AI tries to use `fico_score` in `STAGE_1_KNOCKOUT`, the graph proves mathematically that this is impossible, because `fico_score` is fetched by an API only available in `STAGE_2`.

---

## 3. The Internal API Contract (Service 2 -> Service 3)

This is the exact REST interface the Python orchestrator uses to pull the dynamic constraints from the Java service.

### Request: Fetch Dictionary Context Sub-Graph
* **Endpoint:** `POST /internal/graph/context` (Hosted on Service 3)
* **Request Body:**
```json
{
  "draft_id": "drf_883abc91",
  "extracted_keywords": ["fico", "equifax", "lexisnexis", "texas"],
  "product_code": "UNSECURED_PERSONAL"
}
```

### Response (200 OK):
The Java service returns a highly pruned JSON Schema containing *only* what the LLM needs, preventing token limits from blowing up.

```json
{
  "pruned_json_schema": {
    "credit_bureau": {
      "fico_score": {"type": "integer"},
      "months_since_oldest_tradeline": {"type": "integer"}
    }
  },
  "allowed_metadata": {
    "valid_execution_stages": ["STAGE_2_BUREAU", "STAGE_3_ALTERNATIVE_DATA"],
    "required_enrichment_dependencies": ["EQUIFAX_PRIMARY"],
    "allowed_target_apis": ["LEXIS_NEXIS_RISKVIEW"]
  },
  "graph_warnings": [
    "LEXIS_NEXIS_RISKVIEW can only be invoked if EQUIFAX_PRIMARY has already been executed or has failed."
  ]
}
```

---

## 4. The Cypher Query (Executed by Service 3)

For your backend Java engineers, this is the actual Neo4j Cypher query they will write to fulfill the API request above. It traverses the graph from the requested fields up to the API and Stage constraints.

```cypher
// Match the specific data fields requested by the AI orchestrator
MATCH (field:DataField)
WHERE field.name IN ['fico_score', 'months_since_oldest_tradeline']

// Traverse up to find which Entity owns them (e.g., credit_bureau)
OPTIONAL MATCH (field)-[:BELONGS_TO]->(entity:Entity)

// Traverse further to find which APIs provide this data and in what stages
OPTIONAL MATCH (entity)-[:FETCHED_BY]->(api:ExternalAPI)-[:AVAILABLE_IN]->(stage:ExecutionStage)

// Return the aggregated schema map
RETURN 
  entity.name AS Category, 
  collect(field.name) AS Fields, 
  collect(DISTINCT api.name) AS RequiredAPIs,
  collect(DISTINCT stage.name) AS ValidStages
```

## 5. How LangGraph Uses This Data

Once Service 2 (Python) receives the payload from Service 3, it dynamically constructs the `SystemMessage` for the primary LangGraph generation node:

```python
# Python LangGraph Node snippet
def generate_rule_contract(state: GraphState):
    
    # 1. Fetch context from Java Service
    graph_context = call_java_graph_service(state["original_intent"])
    
    # 2. Build the rigid system prompt
    system_prompt = f"""
    You are an enterprise rule architect. Map the intent to a JSON contract.
    
    CRITICAL CONSTRAINTS PULLED FROM GRAPH DB:
    - You may ONLY use these stages: {graph_context['allowed_metadata']['valid_execution_stages']}
    - You may ONLY call these APIs: {graph_context['allowed_metadata']['allowed_target_apis']}
    - WARNING: {graph_context['graph_warnings'][0]}
    
    AVAILABLE SCHEMA FOR SpEL:
    {json.dumps(graph_context['pruned_json_schema'])}
    """
    
    # 3. Execute LLM call
    response = llm.invoke([SystemMessage(content=system_prompt), HumanMessage(content=state["original_intent"])])
    
    return {"current_draft_json": response.content}
```