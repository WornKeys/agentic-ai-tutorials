# Architecture Component Matrix: The Data Plane (Lean Enterprise Variant)

The Data Plane is the deterministic execution zone. It has zero AI, zero LLMs, and zero human workflows. Its only job is to process JSON payloads against mathematical SpEL strings in sub-100 milliseconds.

## 1. The Execution Gateway (Ingress Layer)
You cannot expose your SpEL engine directly to the internet or even to internal frontends. 
* **Tech Stack:** Spring Cloud Gateway or Kong.
* **Functionality:** * Receives the `POST /evaluate` loan application payload.
    * Performs a lightweight JSON Schema validation to ensure the payload is structurally sound (e.g., ensuring `applicant.age` is an integer, not a string) *before* handing it to the engine.
    * Handles basic rate-limiting and authorization.

## 2. Distributed Rule Cache
The execution engine must never query a relational database. It must pull rules from memory.
* **Tech Stack:** Redis (Cluster Mode).
* **Functionality:** * Stores the approved, active JSON Rule Contracts pushed down from the Control Plane's Immutable Ledger.
    * Key structure: `ruleset:{product_code}:{jurisdiction}:{version}`.
    * The SpEL execution engines maintain a local JVM cache (Caffeine) and only reach out to Redis if they detect a cache-miss or a version bump.

## 3. Cache Sync Daemon (The Bridging Service)
Because we dropped Kafka, you cannot rely on an event-driven stream to push rule updates from the Ledger into Redis.
* **Tech Stack:** Java Spring Boot / Go (Background Worker).
* **Functionality:**
    * Periodically polls the Control Plane's `production_rule_ledger` (e.g., every 5 seconds) looking for new approved hashes.
    * If a new rule version is found, it pulls the JSON contract, writes it to the Redis Cluster, and updates the `active_version` pointer key.

## 4. The SpEL Execution Engine (The Core)
This is the heart of the Data Plane. It must be brutally stateless. You scale this horizontally (e.g., 10 to 50 pods in Kubernetes) based on traffic.
* **Tech Stack:** Java Spring Boot + Spring Expression Language (SpEL).
* **Functionality:**
    * Receives the loan payload from the Gateway.
    * Pulls the matching Rule Set from the local/Redis cache.
    * Evaluates the application against the `spel_expression` strings in a strict waterfall order (Knockouts -> Bureau -> Affordability).
    * If a rule triggers `SUSPEND_AND_ENRICH`, it pauses execution and forwards the payload to the Orchestration Layer to fetch API data.
    * Constructs a final `Decision_Event` JSON containing the input data, the list of rules that fired, and the final outcome (Approve/Decline).

## 5. The Message Broker (The Kafka Replacement)
The Execution Engine must log every decision for compliance, but it cannot wait for a database write. It must fire-and-forget the audit log and immediately return the HTTP response to the Gateway.
* **Tech Stack:** RabbitMQ.
* **Functionality:**
    * **Why RabbitMQ?** It is lighter than Kafka, easier to host, and uses Advanced Message Queuing Protocol (AMQP). It excels at complex routing rather than infinite log retention.
    * The Execution Engine publishes the `Decision_Event` JSON to a RabbitMQ Exchange (e.g., `exchange.decisions`).
    * RabbitMQ guarantees delivery to the downstream reporting consumers without blocking the SpEL evaluation thread.

## 6. Audit Sink & Simplistic Reporting (The Snowflake Workaround)
If you are not paying for a massive OLAP data warehouse like Snowflake or Redshift, you must push your transactional database (PostgreSQL) to its absolute limits using JSONB and Materialized Views.
* **Tech Stack:** PostgreSQL (Dedicated Read/Write instance, separate from the Control Plane DB) + pg_cron.
* **Functionality:**
    * **The Audit Consumer:** A lightweight microservice listens to the RabbitMQ queue and blindly inserts the `Decision_Event` JSON into an append-only Postgres table (`execution_audit_log`) using a `JSONB` column.
    * **The Reporting Workaround:** Querying 10 million rows of JSONB data for a dashboard will crash your database. You solve this with **Materialized Views**.
    * You write SQL scripts that extract key metrics from the JSONB (e.g., `total_applications`, `decline_rate_by_jurisdiction`, `rules_triggered_count`).
    * You use `pg_cron` to refresh these Materialized Views every 15 minutes. 
    * Your Business Intelligence tools (Tableau, Metabase, or a custom UI) query the *Materialized Views*, not the raw JSONB table. This provides sub-second dashboard load times without requiring an enterprise data warehouse.