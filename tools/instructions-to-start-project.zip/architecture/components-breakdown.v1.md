# Architecture Component Matrix: Enterprise AI-Augmented Lending Platform (Immutable DB Variant)

## 1. The Gateway & Ingress Layer
This layer protects the internal network and routes traffic based on whether the request is a slow, probabilistic authoring task or a microsecond-latency decisioning task.

* **Enterprise API Gateway / WAF**
    * **Purpose:** Handles rate limiting, DDoS protection, SSL termination, and routes incoming traffic.
    * **Interface:** Exposes public/internal REST endpoints (`/api/v1/decisions/evaluate`, `/api/v1/rules/draft`).
* **Identity & Access Management (IAM) / OIDC Provider**
    * **Purpose:** Enforces strict Role-Based Access Control (RBAC). A business user can draft a rule, but only a senior underwriter can approve it.
    * **Interface:** OAuth2/SAML tokens validated at the Gateway.

## 2. AI Control Plane (The Probabilistic Zone)
This is the "slow" subnet. It handles human interaction, multi-agent reasoning, and safety guardrails. Nothing here touches a live loan application.

* **Authoring & Intent Service**
    * **Purpose:** The backend for the frontend. It manages the user session, saves UI drafts, and triggers the orchestrator.
    * **Interface:** REST/GraphQL API for the Business Analyst UI.
* **LLM Agent Orchestrator (e.g., LangGraph / Semantic Kernel)**
    * **Purpose:** The brain of the control plane. It manages the multi-step agent workflow: retrieving context, prompting the LLM, catching errors, and forcing self-correction loops.
    * **Interface:** Internal RPC or REST; connects to the LLM Gateway and the Neo4j Graph.
* **Enterprise LLM Gateway**
    * **Purpose:** Never call the raw LLM API directly. This proxy layer handles PII scrubbing (ensuring no customer data leaks into prompts), token rate limiting, and model routing.
    * **Interface:** Acts as a drop-in replacement for the standard OpenAI/Bedrock REST API.
* **Data Dictionary & Dependency Graph (Graph DB - Neo4j)**
    * **Purpose:** Maps the entire lending data model. It tracks which variables are used by which rules to prevent developers from deleting a field that an active rule requires.
    * **Interface:** Cypher query language / GraphQL interface for the Orchestrator to pull context.
* **Rule Validator Engine**
    * **Purpose:** The deterministic bouncer for the AI. It strictly evaluates the AI's JSON output against your JSON Schema and business logic constraints.
    * **Interface:** `validate(JSONObject generatedRule, JSONSchema dictionary) -> Result<ValidRule, ErrorList>`
* **Simulation & Scenario Service**
    * **Purpose:** Executes shadow testing. It pulls historical payload data and runs it through the newly proposed rule to generate an impact analysis.
    * **Interface:** `POST /simulate { rule_id, dataset_id } -> DiffReport`

## 3. Governance & State Management (The Source of Truth)
This layer ensures that you can survive a regulatory audit. It guarantees immutability natively through database constraints rather than file version control.

* **Control Database (Relational - e.g., PostgreSQL)**
    * **Purpose:** Stores transient, mutable data: user sessions, work-in-progress rule drafts, simulation reports, and the metadata of the data dictionary.
    * **Interface:** Standard SQL / ORM via the Authoring Service.
* **Immutable Ledger Database (e.g., Amazon QLDB / Datomic / Append-Only Postgres)**
    * **Purpose:** The absolute, cryptographic source of truth for production rules. It is strictly APPEND-ONLY. When a rule is approved, it is inserted here as a new block/revision with a cryptographic hash. Previous versions cannot be altered or deleted.
    * **Interface:** Ledger-specific query language (e.g., PartiQL for QLDB) / Cryptographic Verification APIs.
* **Rule Promotion & Deployment Service**
    * **Purpose:** Replaces the CI/CD Git pipeline. When a Senior Underwriter approves a rule in the UI, this service cryptographically signs the JSON contract, commits it to the Ledger DB, and immediately publishes a "Deployment Event."
    * **Interface:** Listens to Maker-Checker approval events from the Authoring Service; Publishes deployment commands to the Event Bus.

## 4. Data Plane (The Deterministic Execution Zone)
This is the high-performance subnet. It has zero knowledge of AI, prompts, or agents. It only knows mathematics and JSON.

* **Cache Sync Service (CDC/Event-Driven)**
    * **Purpose:** Listens to the Deployment Service (via Kafka/SNS) or reads Change Data Capture (CDC) streams directly from the Ledger Database. When a new rule is appended, it safely invalidates the old cache and warms up the new rules without dropping live traffic.
    * **Interface:** Message consumer; Redis/Memcached client protocols for writing.
* **Distributed Rule Cache (e.g., Redis / ElastiCache)**
    * **Purpose:** Holds the active JSON rule contracts in memory. This prevents the execution engine from ever making a slow database call.
    * **Interface:** Key-Value retrieval (e.g., `GET /rules/active_set`).
* **High-Throughput Rule Engine (Custom Spring Boot + SpEL)**
    * **Purpose:** The mathematical execution core. It receives a loan application, pulls the active rules from the local/distributed cache, evaluates the SpEL logic, and outputs a strict Approve/Decline/Refer decision.
    * **Interface:** `POST /evaluate { ApplicantJSON } -> DecisionContract` (Synchronous, ultra-low latency).

## 5. Observability & Audit (The Compliance Layer)
If you cannot explain a decision, the decision is illegal. This layer guarantees perfect traceability for historical executions.

* **Decision Event Bus (e.g., Apache Kafka / Amazon MSK)**
    * **Purpose:** The Rule Engine cannot afford to wait for a database write. It fires the full execution context (Input, Rules Fired, Output) to this broker asynchronously.
    * **Interface:** Kafka Topics (e.g., `topic.credit.decisions.raw`).
* **Immutable Trace Database (OLAP - e.g., Snowflake / Apache Druid)**
    * **Purpose:** Consumes events from the Event Bus. Optimized for massive time-series queries. If an auditor asks, "Why was John Doe declined on October 12th?", this database reconstructs the exact state of the engine at that millisecond.
    * **Interface:** Complex analytical SQL queries.
* **Application Performance Monitoring (APM - e.g., Datadog / AppDynamics)**
    * **Purpose:** Monitors memory leaks in the SpEL evaluator, tracks latency between the gateway and the engine, and alerts on caching failures.
    * **Interface:** Native APM agents attached to JVMs and Gateways.