# Deep Dive: Service 1 - Authoring BFF (Backend-For-Frontend)

If you are going to build the Backend-For-Frontend (BFF), you must understand its true purpose. It is not just a pass-through proxy. The BFF is the **state manager and the shock absorber**. 

LLMs take anywhere from 3 to 15 seconds to generate a response. If you expose a synchronous `POST` request to your React frontend and hold the HTTP connection open while LangGraph loops in the background, browser timeouts and network hiccups will destroy your user experience, and you will have zombie threads piling up on your server.

This API contract enforces an **Asynchronous Polling Pattern**. You accept the request, immediately return a `202 Accepted` with a tracking ID, and force the frontend to poll for the result. 

---

## Global Request Requirements

Every API call to the BFF must include these headers. If they are missing, the Gateway or BFF drops the request immediately.
* `Authorization: Bearer <JWT>` (Standard OIDC token containing the user's roles and employee ID).
* `X-Correlation-ID: <UUID>` (Mandatory for tracing a single user click through the BFF, into the Python Orchestrator, and down to the OpenAI Gateway).

---

## API 1: Initialize the Draft State

Before the user types a single word of intent, you must establish the boundary conditions (Product, Portfolio, Jurisdiction). This tells the downstream Orchestrator which slice of the Data Dictionary to retrieve.

* **Endpoint:** `POST /api/v1/authoring/drafts`
* **Request Body:**
```json
{
  "portfolio_id": "RETAIL_LENDING",
  "product_code": "UNSECURED_PERSONAL",
  "jurisdiction": "US-TX"
}
```
* **Response (201 Created):**
```json
{
  "draft_id": "drf_883abc91",
  "status": "DRAFT_INITIALIZED",
  "created_by": "emp_49221",
  "created_at": "2026-04-11T08:20:00Z"
}
```

---

## API 2: Submit Intent (The Async Trigger)

The user types their plain English rule and clicks "Generate." This endpoint updates the database and fires a message (via RabbitMQ/Kafka or async gRPC) to the Python LangGraph Orchestrator.

* **Endpoint:** `PUT /api/v1/authoring/drafts/{draft_id}/intent`
* **Request Body:**
```json
{
  "user_intent": "Decline anyone with a FICO under 650 unless they have been at their current job for over 24 months."
}
```
* **Response (202 Accepted):**
```json
{
  "draft_id": "drf_883abc91",
  "task_id": "tsk_generation_9912",
  "status": "PROCESSING_INTENT",
  "estimated_completion_seconds": 12
}
```

---

## API 3: Poll for Generation Status

The UI polls this endpoint every 2 seconds using the `task_id` returned from API 2.

* **Endpoint:** `GET /api/v1/authoring/tasks/{task_id}`
* **Response - While Processing (200 OK):**
```json
{
  "task_id": "tsk_generation_9912",
  "status": "PROCESSING",
  "internal_step": "VALIDATING_JSON_SCHEMA" 
}
```
* **Response - On Success (200 OK):**
```json
{
  "task_id": "tsk_generation_9912",
  "status": "SUCCESS",
  "draft_state": {
    "draft_id": "drf_883abc91",
    "generated_rule": {
      "intent": "Decline applicants with FICO < 650 and employment duration <= 24 months.",
      "spel_expression": "credit_bureau.fico_score < 650 and employment.months_with_current_employer <= 24",
      "decision_action": "DECLINE"
    }
  }
}
```

---

## API 4: Trigger Shadow Simulation

Once the rule is generated, the user clicks "Simulate" to test it against historical data. Running SpEL against 500,000 JSON payloads takes time, so this is also asynchronous.

* **Endpoint:** `POST /api/v1/authoring/drafts/{draft_id}/simulate`
* **Request Body:**
```json
{
  "dataset_id": "DS_2025_Q4_DECLINES",
  "sample_size": 100000
}
```
* **Response (202 Accepted):**
```json
{
  "simulation_job_id": "sim_job_4041",
  "status": "QUEUED"
}
```
*(Note: The UI will poll a `/simulations/{job_id}` endpoint, similar to API 3, to get the final pie charts and impact metrics).*

---

## API 5: Submit for Checker Approval

The Maker is satisfied with the SpEL logic and the simulation results. They lock the draft and send it to the Immutable Ledger (or GitOps queue) for Checker review.

* **Endpoint:** `POST /api/v1/authoring/drafts/{draft_id}/submit`
* **Request Body:**
```json
{
  "maker_notes": "Tested against Q4 data. Confirmed it isolates high-risk thin files without impacting core approvals."
}
```
* **Response (200 OK):**
```json
{
  "draft_id": "drf_883abc91",
  "status": "PENDING_CHECKER_APPROVAL",
  "submitted_at": "2026-04-11T08:35:00Z"
}
```

---

## Strict Error Handling (RFC 7807 Problem Details)

You cannot just throw a generic `500 Internal Server Error` when the AI hallucinates. Your UI needs to know exactly *why* it failed so it can guide the user. The BFF must map backend orchestration failures to strict HTTP status codes.

### 1. The "AI Hallucination / Unmappable Intent" Error (422)
If the LangGraph loop exhausts its retries because the user asked for a variable that does not exist in the Data Dictionary (e.g., "social media sentiment"), the BFF returns a `422 Unprocessable Entity`.

```json
{
  "type": "[https://errors.lending.internal/ai-mapping-failure](https://errors.lending.internal/ai-mapping-failure)",
  "title": "Intent Cannot Be Mapped to Dictionary",
  "status": 422,
  "detail": "The AI orchestrator could not translate your intent into valid SpEL logic after 3 attempts.",
  "actionable_feedback": "You referenced 'rent payment history', which is not in the US-TX Unsecured Lending dictionary. Did you mean 'monthly_housing_payment'?",
  "trace_id": "uuid-1234-5678"
}
```

### 2. The "Maker-Checker Violation" Error (403)
If the user who created the draft attempts to call the `/approve` endpoint, the system must block it.

```json
{
  "type": "[https://errors.lending.internal/rbac-violation](https://errors.lending.internal/rbac-violation)",
  "title": "Maker-Checker Policy Violation",
  "status": 403,
  "detail": "The user attempting to approve this rule is the same user who authored it. Financial compliance requires four-eyes review.",
  "user_id": "emp_49221"
}
```

### 3. The "LLM Rate Limit / Cost Control" Error (429)
Business analysts will spam the "Generate" button if the result isn't perfect. You must rate-limit them at the BFF layer to prevent burning thousands of dollars on GPT-4 API calls.

```json
{
  "type": "[https://errors.lending.internal/rate-limit-exceeded](https://errors.lending.internal/rate-limit-exceeded)",
  "title": "Generation Rate Limit Exceeded",
  "status": 429,
  "detail": "You have exceeded the maximum of 15 rule generation attempts per hour.",
  "retry_after_seconds": 1200
}
```

### 4. The "Logical Conflict" Error (409)
If the Deterministic Validator checks Neo4j and realizes the proposed rule directly contradicts a locked compliance rule.

```json
{
  "type": "[https://errors.lending.internal/logical-conflict](https://errors.lending.internal/logical-conflict)",
  "title": "Rule Logic Conflict Detected",
  "status": 409,
  "detail": "Your proposed rule conflicts with an active mandatory compliance rule.",
  "conflicting_rule_id": "RUL-COMP-001",
  "actionable_feedback": "Your rule approves applicants with a FICO > 600, but RUL-COMP-001 mandates a hard decline for any FICO < 620 in the US-TX jurisdiction."
}
```