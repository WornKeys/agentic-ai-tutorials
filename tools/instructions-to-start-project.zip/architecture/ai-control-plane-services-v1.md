# Architecture Component Matrix: AI Control Plane (Polyglot Microservices)

To build this correctly, the Control Plane must be a **polyglot microservices cluster**. Here are the four distinct internal services, exposing a mix of public-facing (UI) and private internal APIs.

## Service 1: Authoring BFF (Backend-For-Frontend)
**Tech Stack:** Java (Spring Boot) or Node.js
**Purpose:** This is the only service the React/Angular UI talks to. It manages user sessions, handles RBAC (Maker/Checker roles), stores ephemeral drafts in PostgreSQL, and acts as the async traffic cop. Because LLMs are slow, this service translates synchronous UI clicks into asynchronous backend jobs.

**Exposed APIs (External facing to UI):**
* **`POST /api/v1/drafts`**
    * **Payload:** `{ "portfolio_id": "...", "product_code": "..." }`
    * **Action:** Initializes a blank rule draft in Postgres and returns a `draft_id`.
* **`PUT /api/v1/drafts/{draft_id}/intent`**
    * **Payload:** `{ "user_intent": "Plain English string..." }`
    * **Action:** Updates the draft with the user's text and fires an async message to the Agent Orchestrator. Returns a `202 Accepted` with a `task_id` for UI polling.
* **`GET /api/v1/drafts/{draft_id}/status`**
    * **Response:** `{ "status": "GENERATING | VALIDATING | COMPLETE | FAILED", "generated_rule": {...} }`
    * **Action:** The UI polls this endpoint to update the loading spinner.
* **`POST /api/v1/drafts/{draft_id}/submit-approval`**
    * **Action:** Locks the draft and alerts the Rule Promotion Service (Immutable Ledger) that a rule is ready for Checker review.

## Service 2: The Agent Orchestrator
**Tech Stack:** Python (FastAPI + LangGraph)
**Purpose:** This is the "brain." It contains zero business logic; it is purely an orchestration engine. It receives intents, queries the Graph Service for context, calls the Enterprise LLM (GPT-4/Claude), and loops through self-correction prompts if the Validator rejects the output. 

**Exposed APIs (Strictly Internal/Private):**
* **`POST /internal/orchestrate/generate`**
    * **Payload:** `{ "draft_id": "...", "intent": "...", "max_retries": 3 }`
    * **Action:** Triggers the LangGraph multi-agent loop.
* **`POST /internal/orchestrate/explain`**
    * **Payload:** `{ "spel_expression": "..." }`
    * **Action:** Reverse-translation. If a user wants to read a legacy rule, the LLM translates the SpEL string back into plain English.

## Service 3: Validation & Graph Service (The Guardrail)
**Tech Stack:** Java (Spring Boot) + Neo4j Driver
**Purpose:** This is the most critical service in the Control Plane. It must be written in the exact same language as your Data Plane (Java) because it must use the exact same SpEL compiler. If you try to write a SpEL validator in Python, you will get false positives. It also holds the Data Dictionary graph.

**Exposed APIs (Strictly Internal/Private):**
* **`POST /internal/validate/schema-and-syntax`**
    * **Payload:** `{ "generated_json": {...} }`
    * **Action:** Validates the JSON against the Draft 2020-12 Schema and attempts a dry-run compile of the `spel_expression`. Returns `{"valid": true}` or a strict array of compiler errors for the LLM to read.
* **`POST /internal/validate/business-conflicts`**
    * **Payload:** `{ "spel_expression": "..." }`
    * **Action:** Queries Neo4j to ensure the rule doesn't create a logical dead-end (e.g., Rule A says "Approve if > 700", new Rule B says "Decline if > 700").
* **`GET /internal/graph/context`**
    * **Query Params:** `