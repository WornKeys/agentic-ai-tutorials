```sql
-- 1. Create Enums for State Management
CREATE TYPE draft_status AS ENUM (
    'DRAFT_INITIALIZED',
    'PROCESSING_INTENT',
    'DRAFT_VALIDATED',
    'GENERATION_FAILED',
    'SIMULATED',
    'PENDING_CHECKER_APPROVAL',
    'APPROVED',
    'REJECTED'
);

-- 2. Create the Primary Drafts Table
CREATE TABLE authoring_rule_drafts (
    draft_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- Context Boundaries
    portfolio_id VARCHAR(50) NOT NULL,
    product_code VARCHAR(50) NOT NULL,
    jurisdiction VARCHAR(10) NOT NULL,
    
    -- State & Workflow Tracking
    status draft_status NOT NULL DEFAULT 'DRAFT_INITIALIZED',
    maker_id VARCHAR(100) NOT NULL, -- Employee ID of the Business Analyst
    checker_id VARCHAR(100),        -- Employee ID of the Senior Approver (must be different from maker_id)
    
    -- The Human Input
    user_intent TEXT,               -- The raw English prompt provided by the Maker
    maker_notes TEXT,               -- Justification submitted during approval request
    checker_notes TEXT,             -- Rejection or approval notes from the Checker
    
    -- The Machine Output (Stored as JSONB for indexing and flexibility)
    generated_contract JSONB,       -- The exact JSON output from the AI Orchestrator (SpEL, Enums, Routing)
    validation_errors JSONB,        -- Array of errors if the Graph/Syntax Validator rejected it
    
    -- Audit Timestamps
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    submitted_at TIMESTAMP WITH TIME ZONE,
    resolved_at TIMESTAMP WITH TIME ZONE,
    
    -- Maker-Checker Constraint: A user cannot approve their own draft
    CONSTRAINT chk_maker_checker_diff CHECK (maker_id != checker_id)
);

-- 3. Create the Simulations Tracking Table (1-to-Many relationship with Drafts)
CREATE TABLE rule_simulations (
    simulation_job_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    draft_id UUID NOT NULL REFERENCES authoring_rule_drafts(draft_id) ON DELETE CASCADE,
    
    dataset_id VARCHAR(100) NOT NULL, -- e.g., 'DS_2025_Q4_DECLINES'
    sample_size INTEGER NOT NULL,
    status VARCHAR(20) NOT NULL,      -- 'QUEUED', 'RUNNING', 'SUCCESS', 'FAILED'
    
    -- The Financial Impact Results
    impact_metrics JSONB,             -- Stores the delta (e.g., approval rate changes, default reduction)
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP WITH TIME ZONE
);

-- 4. Create Performance Indexes for the BFF Service
-- Fast lookup for a user's dashboard (e.g., "Show me all my pending drafts")
CREATE INDEX idx_drafts_maker_status ON authoring_rule_drafts(maker_id, status);

-- Fast lookup for the Checker's dashboard (e.g., "Show me everything waiting for approval")
CREATE INDEX idx_drafts_pending_approval ON authoring_rule_drafts(status) 
WHERE status = 'PENDING_CHECKER_APPROVAL';

-- GIN Index on the JSONB column to allow querying deep inside the AI contract 
-- (e.g., "Find all drafts that use the EQUIFAX_PRIMARY enrichment dependency")
CREATE INDEX idx_drafts_contract_jsonb ON authoring_rule_drafts USING GIN (generated_contract);
```