# Rule Structure v1

## Why This Structure Survives Production

This structure bridges the gap between static logic and a dynamic, multi-stage microservice architecture.

## 1. The `routing_metadata` Block (The Eligibility Matrix)

In reality, you do not query the cache for “all active rules.” The Orchestration layer queries the cache for rules matching the specific dimensions of the incoming application.

- `execution_stage`: Prevents the engine from running Stage 3 Affordability rules before Stage 1 Identity rules have passed.
- `jurisdictions` & `product_codes`: If the payload says the state is `US-FL` and the product is `MORTGAGE`, this specific rule is ignored entirely. This keeps the execution matrix tiny and lightning-fast.

## 2. The `enrichment_dependencies` Array (The Orchestrator's Checklist)

Before the SpEL engine is even allowed to look at this rule, the Orchestration Layer checks this array.

If this array lists `EQUIFAX_PRIMARY`, the orchestrator checks the incoming JSON payload. If the Equifax data block is missing, the orchestrator halts, makes the Equifax API call, appends the data to the JSON, and then hands it to the SpEL engine. This guarantees the SpEL engine never throws a “Null Pointer Exception” because of missing data.

## 3. The `SUSPEND_AND_ENRICH` Action (Handling Third-Party APIs Safely)

This is how you handle your third-party API requirement without breaking the execution engine.

- The SpEL expression evaluates the logic: `fico_score == 0`.
- It returns `true`.
- Instead of outputting `DECLINE`, it outputs `SUSPEND_AND_ENRICH`.

The stateless Rule Engine immediately stops evaluating the current rule set, emits the payload back to the Kafka Event Bus with the `action_payload` attached, and frees up its thread.

The external Orchestration Layer reads that event, makes the slow HTTP call to the `LEXIS_NEXIS_RISKVIEW` API, appends the new data to the payload, updates the state to `STAGE_3_ALTERNATIVE_DATA`, and drops it back into the engine’s queue for a fresh evaluation.

This design gives you the exact capability you asked for—conditional third-party API invocation—while keeping your core execution engine 100% deterministic, mathematically pure, and capable of processing thousands of evaluations per second without I/O blocking.
