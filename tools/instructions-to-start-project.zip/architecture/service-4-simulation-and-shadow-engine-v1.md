# API Contract: Service 4 - Simulation & Shadow Engine

**Critical Architecture Note:** A syntax error in a rule will crash the engine, but a logical error will bankrupt the company. Service 3 prevents the former; Service 4 prevents the latter. 

This service cannot be a lightweight REST API. Evaluating a new SpEL expression against 500,000 historical loan applications requires serious compute. This service is typically built using **Java (Spring Batch) or Apache Spark**, operating as an asynchronous job manager. It maintains an embedded, exact-replica instance of your Data Plane execution engine to guarantee 100% parity.

## API 1: Trigger Simulation Job (Async)
This endpoint initiates the batch processing job. It does not return the results; it returns a tracking ID.

* **Endpoint:** `POST /internal/simulations/jobs` *(Note: Called by Service 1 BFF, which exposes a public version to the UI)*
* **Request Body:**
```json
{
  "draft_id": "drf_883abc91",
  "dataset_id": "DS_2025_Q4_UNSECURED_BASE",
  "sample_size": 250000,
  "baseline_ruleset_version": "v1.44.2"
}
```
* **Response - Accepted (202 Accepted):**
```json
{
  "job_id": "sim_job_99a8b1",
  "status": "QUEUED",
  "cluster_allocation": "MEDIUM",
  "estimated_completion_seconds": 45
}
```

## API 2: Poll Job Status
The BFF polls this endpoint to update the UI progress bar.

* **Endpoint:** `GET /internal/simulations/jobs/{job_id}/status`
* **Response (200 OK):**
```json
{
  "job_id": "sim_job_99a8b1",
  "status": "RUNNING",
  "progress_percent": 68.5,
  "records_processed": 171250,
  "total_records": 250000
}
```

## API 3: Retrieve Simulation Impact Report
Once the job is `SUCCESS`, this endpoint returns the aggregated financial and risk delta. It does not return 250,000 rows; it returns the pre-calculated OLAP metrics.

* **Endpoint:** `GET /internal/simulations/jobs/{job_id}/results`
* **Response (200 OK):**
```json
{
  "job_id": "sim_job_99a8b1",
  "dataset_id": "DS_2025_Q4_UNSECURED_BASE",
  "total_evaluated": 250000,
  "execution_time_ms": 42100,
  "impact_metrics": {
    "baseline_approval_rate": 42.1,
    "new_approval_rate": 39.8,
    "approval_rate_delta": -2.3,
    "projected_default_reduction_bps": 45
  },
  "waterfall_analysis": {
    "previously_approved_now_declined": 5750,
    "previously_declined_now_approved": 0,
    "triggered_by_new_rule": 5750
  },
  "demographic_fair_lending_proxy": {
    "status": "PASS",
    "disparate_impact_ratio": 0.92 
  }
}
```

## API 4: List Available Datasets
The UI needs to know which historical datasets the business analyst is allowed to test against.

* **Endpoint:** `GET /internal/simulations/datasets`
* **Response (200 OK):**
```json
{
  "datasets": [
    {
      "dataset_id": "DS_2025_Q4_UNSECURED_BASE",
      "description": "All unsecured applications from Q4 2025.",
      "record_count": 512040,
      "contains_defaults": true
    },
    {
      "dataset_id": "DS_TEXAS_EDGE_CASES",
      "description": "Thin file applications in TX to test alternative data routing.",
      "record_count": 14000,
      "contains_defaults": false
    }
  ]
}
```

---

## Strict Error Handling (RFC 7807 Problem Details)

Batch processing over massive datasets fails in unique ways. The APIs must communicate cluster issues, data corruption, and state violations clearly.

### 1. The "Premature Simulation" Error (422)
You cannot simulate a rule that has not passed Service 3's strict validation. If the UI tries to bypass the workflow, this triggers.

```json
{
  "type": "[https://errors.lending.internal/simulation/draft-not-validated](https://errors.lending.internal/simulation/draft-not-validated)",
  "title": "Draft Rule Not Validated",
  "status": 422,
  "detail": "Cannot simulate draft_id 'drf_883abc91' because its status is not 'DRAFT_VALIDATED'.",
  "current_status": "PROCESSING_INTENT"
}
```

### 2. Compute Cluster Exhaustion (429)
If ten analysts click "Simulate" at the same time on 1-million-record datasets, your Spark cluster or ThreadPool will exhaust.

```json
{
  "type": "[https://errors.lending.internal/simulation/cluster-at-capacity](https://errors.lending.internal/simulation/cluster-at-capacity)",
  "title": "Compute Resources Exhausted",
  "status": 429,
  "detail": "The simulation cluster is currently processing the maximum allowed concurrent jobs.",
  "active_jobs": 5,
  "retry_after_seconds": 60
}
```

### 3. Data Dictionary Drift / Payload Incompatibility (500)
If the analyst selects a dataset from 2022, but the rule uses a variable added to the dictionary in 2024, the SpEL engine will crash with missing data mid-run.

```json
{
  "type": "[https://errors.lending.internal/simulation/payload-incompatibility](https://errors.lending.internal/simulation/payload-incompatibility)",
  "title": "Historical Payload Incompatible",
  "status": 500,
  "detail": "The simulation aborted at record 14,022. The historical dataset is missing fields required by the new rule.",
  "missing_field": "credit_bureau.revolving_utilization_percent",
  "resolution": "Select a dataset compiled after Q2 2024."
}
```

---

## Required Development Architecture for the Shadow Engine

To build this service efficiently, your engineers must adhere to data gravity and deterministic isolation.

### 1. The "Delta Matrix" Approach
Do not evaluate *just* the new rule. A simulation is worthless without a baseline.
* The historical dataset in your Data Lake must contain the **historical outcome** (e.g., "This loan was approved in 2025, and it defaulted in 2026").
* The Shadow Engine loads the exact active Production Rule Set (e.g., `v1.44.2`).
* It injects the new Draft Rule into that set.
* It runs the historical payload through the *entire* waterfall.
* It compares the new outcome against the historical outcome. If the new rule declines 5,000 loans that *didn't* default historically, the rule is destroying revenue. If it declines 5,000 loans that *did* default, the rule is a massive success.

### 2. Data Gravity and Storage
Moving 500,000 JSON payloads from an S3 bucket to a Spring Boot JVM over the network for every simulation is an architectural disaster. 
* **The Pattern:** The Simulation Service should be deployed as close to the data as possible. If you use Snowflake, compile the SpEL engine into a Java UDF (User Defined Function) and run the execution *inside* the Snowflake warehouse. If you use AWS, run this service on EMR/Spark directly against the S3 Parquet files.

### 3. PII Scrubbing (Compliance Mandate)
Historical data contains Social Security Numbers, names, and exact addresses.
* **The Rule:** The datasets queried by API 4 must be pre-scrubbed. The Shadow Engine must never load raw PII into memory. Furthermore, while the rule execution engine is blind to protected classes (race, gender), the Data Science team *does* maintain that metadata in isolated, hashed datasets. The Simulation engine calculates the `"disparate_impact_ratio"` (seen in API 3) securely to warn analysts if their seemingly math-based rule accidentally redlines a demographic, stopping a Fair Lending violation before it reaches production.